-- In order to load a custom language, you must make a .po file for that language and load it here.

LoadPOFile("czech.po", "fr")

-- More information on this process can be found here: http://forums.kleientertainment.com/index.php?/topic/10292-creating-a-translation-using-the-po-format/
