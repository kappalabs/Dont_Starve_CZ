name = "Czech Language Pack"
description = "Balicek s ceskym prekladem."
author = "Kappa"
version = "1.0"

-- This is the URL name of the mod's thread on the forum; the part after the index.php? and before the first & in the URL
-- Example:
-- http://forums.kleientertainment.com/index.php?/files/file/202-sample-mods/
-- becomes
-- /files/file/202-sample-mods/
 forumthread = "/files/file/202-sample-mods/"

api_version = 3

--icon_atlas = "czechlanguage.xml"
--icon = "czechlanguage.tex"
